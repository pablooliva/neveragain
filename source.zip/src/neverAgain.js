import * as Mark from 'mark.js';
window.onload = function () {
    window.alert('loaded');
    var markInstance = new Mark(document.body);
    markInstance.mark('Using');
};
//# sourceMappingURL=neverAgain.js.map