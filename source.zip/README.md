![Never Again](https://never-aga.in/images/never-again-logo.svg "Never Again forget")

# Never Again

A simple browser extension to help us never again forget those that are driving life on this planet to extinction.

The extension highlights companies and individuals that are aggressively contributing towards climate change. This is done by literally highlighting the name of the transgressor on a web page. When you hover over the highlight, you are presented with an abbreviated description of the offense and a link to additional information.

![Never Again extension example](https://never-aga.in/images/extension-in-action.png "Never Again extension example")

## Website

[never-aga.in](https://never-aga.in)
